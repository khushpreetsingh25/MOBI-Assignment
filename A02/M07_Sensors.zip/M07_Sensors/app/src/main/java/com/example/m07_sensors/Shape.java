// Shape.java
package com.example.m07_sensors;

import android.graphics.Canvas;
import android.graphics.Paint;

public abstract class Shape {
    protected int color;

    public Shape(int color) {
        this.color = color;
    }

    public abstract void draw(Canvas canvas, Paint paint);

    public abstract void move(float deltaX, float deltaY);

    public void changeColor(int newColor) {
        color = newColor;
    }
}
