// Square.java This is my code
package com.example.m07_sensors;

import android.graphics.Canvas;
import android.graphics.Paint;

public class Square extends Shape {
    private float x, y;

    public Square(float x, float y, int color) {
        super(color);
        this.x = x;
        this.y = y;
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        paint.setColor(color);
        // Draw square at (x, y) on the canvas
        float size = 100; // Adjust the size of the square as needed
        canvas.drawRect(x, y, x + size, y + size, paint);
    }
        // Use canvas.drawRect() or similar method


    // Add method to move the square
    public void move(float deltaX, float deltaY) {
        x += deltaX;
        y += deltaY;
    }

    // Add method to change the color of the square
    public void changeColor(int newColor) {
        color = newColor;
    }
}
