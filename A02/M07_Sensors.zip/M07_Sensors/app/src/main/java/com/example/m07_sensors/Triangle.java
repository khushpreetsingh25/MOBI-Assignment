// Triangle.java
package com.example.m07_sensors;

import android.graphics.Canvas;
import android.graphics.Paint;

public class Triangle extends Shape {
    private float centerX, centerY;
    private float rotationAngle = 0;

    public Triangle(float centerX, float centerY, int color) {
        super(color);
        this.centerX = centerX;
        this.centerY = centerY;
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        paint.setColor(color);

        // Draw triangle logic here (e.g., using Path)
        // This is a simple example; you may need to adjust the drawing logic
        float sideLength = 100; // Adjust the side length as needed
        float halfHeight = (float) (sideLength * Math.sqrt(3) / 2);

        canvas.drawLine(centerX, centerY - halfHeight, centerX + sideLength / 2, centerY + halfHeight, paint);
        canvas.drawLine(centerX + sideLength / 2, centerY + halfHeight, centerX - sideLength / 2, centerY + halfHeight, paint);
        canvas.drawLine(centerX - sideLength / 2, centerY + halfHeight, centerX, centerY - halfHeight, paint);
    }

    @Override
    public void move(float deltaX, float deltaY) {
        // Triangle does not move
    }

    @Override
    public void changeColor(int newColor) {
        color = newColor;
    }

    // Add method to spin the triangle
    public void spin() {
        rotationAngle += 5; // Adjust the rotation speed as needed
        if (rotationAngle >= 360) {
            rotationAngle = 0; // Reset angle when it reaches 360 degrees
        }
    }
}

