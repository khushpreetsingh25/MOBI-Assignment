package com.example.m07_sensors;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Formatter;

class BouncingBallView extends View implements SensorEventListener {

    private ArrayList<Ball> balls = new ArrayList<>();
    private ArrayList<Shape> shapes = new ArrayList<>();
    private Box box;
    private StringBuilder statusMsg = new StringBuilder();
    private Formatter formatter = new Formatter(statusMsg);
    private Paint paint;
    private int string_line = 1;
    private int string_x = 10;
    private int string_line_size = 40;
    private ArrayList<String> debug_dump1 = new ArrayList();
    private String[] debug_dump2 = new String[200];
    private float previousX;
    private float previousY;
    double ax = 0;
    double ay = 0;
    double az = 0;

    public BouncingBallView(Context context) {
        super(context);

        box = new Box(Color.BLACK);

        balls.add(new Ball(Color.GREEN));
        balls.add(new Ball(Color.CYAN));

        shapes.add(new Square(Color.BLUE));
        shapes.add(new Triangle(Color.YELLOW));

        paint = new Paint();
        paint.setTypeface(Typeface.MONOSPACE);
        paint.setTextSize(32);
        paint.setColor(Color.CYAN);

        this.setFocusable(true);
        this.requestFocus();
        this.setFocusableInTouchMode(true);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        box.draw(canvas);

        for (Ball b : balls) {
            b.draw(canvas);
            b.moveWithCollisionDetection(box);
        }

        for (Shape shape : shapes) {
            shape.draw(canvas);
            shape.moveWithCollisionDetection(box);
        }

        if (string_line * string_line_size > box.yMax) {
            string_line = 1;
            debug_dump1.clear();
        } else {
            string_line++;
        }

        if (string_x > box.xMax) {
            string_x = 10;
        } else {
            string_x++;
        }

        debug_dump2[string_line] = "Acc(" + ax + ", " + ay + " ," + az + ")";
        for (int i = 1; i < debug_dump2.length; i++) {
            // canvas.drawText(debug_dump2[i], string_x, i * string_line_size, paint);
        }

        this.invalidate();
    }

    @Override
    public void onSizeChanged(int w, int h, int oldW, int oldH) {
        box.set(0, 0, w, h);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float currentX = event.getX();
        float currentY = event.getY();
        float deltaX, deltaY;
        float scalingFactor = 5.0f / ((box.xMax > box.yMax) ? box.yMax : box.xMax);
        float slow_down_speed_factor = 10.0f;
        switch (event.getAction()) {
            case MotionEvent.ACTION_MOVE:
                deltaX = (currentX - previousX) / slow_down_speed_factor;
                deltaY = (currentY - previousY) / slow_down_speed_factor;

                balls.add(new Ball(Color.RED, previousX, previousY, deltaX, deltaY));

                shapes.add(new Square(Color.BLUE, previousX, previousY, deltaX, deltaY));

                shapes.add(new Triangle(Color.YELLOW, previousX, previousY, deltaX, deltaY));

                if (balls.size() > 20) {
                    balls.clear();
                    balls.add(new Ball(Color.GREEN));
                }

                if (shapes.size() > 20) {
                    shapes.clear();
                    shapes.add(new Square(Color.BLUE));
                    shapes.add(new Triangle(Color.YELLOW));
                }
        }

        previousX = currentX;
        previousY = currentY;

        return true;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            ax = -event.values[0];
            ay = event.values[1];
            az = event.values[2];

            for (Ball b : balls) {
                b.setAcc(ax, ay, az);
            }

            for (Shape shape : shapes) {
                shape.setAcc(ax, ay, az);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not implemented for brevity
    }

    private abstract class Shape {
        int color;
        float x, y, size;
        float speedX, speedY;

        Shape(int color) {
            this.color = color;
            this.size = 50; // You can adjust the size as needed
        }

        Shape(int color, float x, float y, float speedX, float speedY) {
            this(color);
            this.x = x;
            this.y = y;
            this.speedX = speedX;
            this.speedY = speedY;
        }

        abstract void draw(Canvas canvas);

        void moveWithCollisionDetection(Box box) {
            x += speedX;
            y += speedY;

            if (x < box.xMin || x + size > box.xMax) {
                speedX = -speedX;
            }

            if (y < box.yMin || y + size > box.yMax) {
                speedY = -speedY;
            }
        }

        void setAcc(double ax, double ay, double az) {
            // Override in subclasses if needed
        }
    }

    private class Square extends Shape {
        Square(int color) {
            super(color);
        }

        Square(int color, float x, float y, float speedX, float speedY) {
            super(color, x, y, speedX, speedY);
        }

        @Override
        void draw(Canvas canvas) {
            paint.setColor(color);
            canvas.drawRect(x, y, x + size, y + size, paint);
        }
    }

    private class Triangle extends Shape {
        Triangle(int color) {
            super(color);
        }

        Triangle(int color, float x, float y, float speedX, float speedY) {
            super(color, x, y, speedX, speedY);
        }

        @Override
        void draw(Canvas canvas) {
            paint.setColor(color);
            Path path = new Path();
            path.moveTo(x, y);
            path.lineTo(x + size, y);
            path.lineTo(x + size / 2, y + size);
            path.close();
            canvas.drawPath(path, paint);
        }
    }

    private class Ball extends Shape {
        Ball(int color) {
            super(color);
        }

        Ball(int color, float x, float y, float speedX, float speedY) {
            super(color, x, y, speedX, speedY);
        }

        @Override
        void draw(Canvas canvas) {
            paint.setColor(color);
            canvas.drawCircle(x + size / 2, y + size / 2, size / 2, paint);
        }
    }

    private class Box {
        int color;
        float xMin, xMax, yMin, yMax;

        Box(int color) {
            this.color = color;
        }

        void set(float xMin, float yMin, float xMax, float yMax) {
            this.xMin = xMin;
            this.xMax = xMax;
            this.yMin = yMin;
            this.yMax = yMax;
        }

        void draw(Canvas canvas) {
            paint.setColor(color);
            canvas.drawRect(xMin, yMin, xMax, yMax, paint);
        }
    }
}
